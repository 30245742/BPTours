package com.example.bptours

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.bptours.ui.theme.TourAppTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.dp


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TourAppTheme {
                TourApp()
            }
        }
    }
}

@Composable
fun TourApp(viewModel: TourViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "Welcome to BP Tours")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { viewModel.loadTours() }) {
            Text("View Tours")
        }
        Spacer(modifier = Modifier.height(16.dp))
        TourList(tours = viewModel.tours)
    }
}

@Composable
fun TourList(tours: List<String>) {
    Column {
        for (tour in tours) {
            BasicText(text = tour)
        }
    }
}

class TourViewModel : androidx.lifecycle.ViewModel() {
    var tours by mutableStateOf(listOf<String>())
        private set

    fun loadTours() {
        tours = listOf("Tour A - London", "Tour B - Paris", "Tour C - Rome")
    }
}
