package com.example.bptours

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TourAppTheme {
                TourApp()
            }
        }
    }
}

@Composable
fun TourApp(viewModel: TourViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(text = "Welcome to BP Tours", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { viewModel.loadTours() }) {
            Text("View Tours")
        }
        Spacer(modifier = Modifier.height(16.dp))
        TourList(tours = viewModel.tours)
    }
}

@Composable
fun TourList(tours: List<String>) {
    Column {
        for (tour in tours) {
            BasicText(text = tour, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

class TourViewModel : androidx.lifecycle.ViewModel() {
    var tours by mutableStateOf(listOf<String>())
        private set

    fun loadTours() {
        tours = listOf("Tour A - London", "Tour B - Paris", "Tour C - Rome")
    }
}

@Composable
fun TourAppTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = Color(0xFF6200EE),
        secondary = Color(0xFF03DAC5),
        background = Color.White,
        surface = Color.White,
        onPrimary = Color.White,
        onSecondary = Color.Black,
        onBackground = Color.Black,
        onSurface = Color.Black
    )

    MaterialTheme(
        colorScheme = colors,
        typography = Typography(),
        content = content
    )
}
