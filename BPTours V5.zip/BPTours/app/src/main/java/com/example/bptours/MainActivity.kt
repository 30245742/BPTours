package com.example.bptours

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URL
import kotlin.math.roundToInt
import androidx.compose.ui.tooling.preview.Preview

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TourAppTheme {
                TourApp()
            }
        }
    }
}

@Composable
fun TourApp(viewModel: TourViewModel = viewModel()) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Welcome to BP Tours",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { viewModel.loadTours() }) {
            Text("View Available Tours")
        }
        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { viewModel.navigateToReviews() }) {
            Text("Reviews")
        }
        Spacer(modifier = Modifier.height(16.dp))

        TourList(tours = viewModel.tours, viewModel = viewModel)
    }
}

@Composable
fun TourList(tours: List<Tour>, viewModel: TourViewModel) {
    LazyColumn {
        items(tours) { tour ->
            TourItem(tour = tour, viewModel = viewModel)
        }
    }
}

@Composable
fun TourItem(tour: Tour, viewModel: TourViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Image(
                painter = painterResource(id = tour.imageRes),
                contentDescription = "Tour Image",
                modifier = Modifier.fillMaxWidth().height(200.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = tour.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
            )
            Text(text = tour.description)
            Text(text = "Weather: ${tour.weather}")
            ReviewSection(tour, viewModel)
        }
    }
}

@Composable
fun ReviewSection(tour: Tour, viewModel: TourViewModel) {
    var reviewText by remember { mutableStateOf("") }
    var rating by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Text(text = "User Reviews", fontWeight = FontWeight.Bold)
        tour.reviews.forEach { review ->
            Text(text = "\"${review.text}\" - ${review.rating}/5 Stars")
        }
        BasicTextField(
            value = reviewText,
            onValueChange = { newText -> reviewText = newText },
            modifier = Modifier.fillMaxWidth().padding(4.dp)
        )
        Row {
            for (i in 1..5) {
                Text(
                    text = if (i <= rating) "★" else "☆",
                    modifier = Modifier.clickable { rating = i },
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

class TourViewModel : androidx.lifecycle.ViewModel() {
    var tours by mutableStateOf(listOf<Tour>())
        private set

    fun loadTours() {
        tours = listOf(
            Tour("London", "Explore London’s landmarks", R.drawable.london, getWeather("London")),
            Tour("Paris", "Discover romantic Paris", R.drawable.paris, getWeather("Paris")),
            Tour("Rome", "Experience ancient Rome", R.drawable.rome, getWeather("Rome")),
            Tour("Berlin", "Enjoy Berlin’s culture", R.drawable.berlin, getWeather("Berlin")),
            Tour("Madrid", "See Madrid’s vibrant life", R.drawable.madrid, getWeather("Madrid"))
        )
    }

    fun addReview(tour: Tour, review: Review) {
        val updatedTours = tours.map {
            if (it.name == tour.name) it.copy(reviews = it.reviews + review) else it
        }
        tours = updatedTours
    }

    private fun getWeather(city: String): String {
        return try {
            val apiKey = "bd5e378503939ddaee76f12ad7a97608"
            val response = URL("https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric").readText()
            val json = JSONObject(response)
            val temp = json.getJSONObject("main").getDouble("temp").roundToInt()
            "${temp}°C"
        } catch (e: Exception) {
            "N/A"
        }
    }

    fun navigateToReviews() {
        // Implement navigation logic here
    }
}

data class Tour(val name: String, val description: String, val imageRes: Int, val weather: String, val reviews: List<Review> = listOf())
data class Review(val text: String, val rating: Int)

@Composable
fun TourAppTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = Color(0xFF6200EE),
        secondary = Color(0xFF03DAC5),
        background = Color.White,
        surface = Color.White,
        onPrimary = Color.White,
        onSecondary = Color.Black,
        onBackground = Color.Black,
        onSurface = Color.Black
    )
    MaterialTheme(
        colorScheme = colors,
        typography = Typography(),
        content = content
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewTourApp() {
    TourAppTheme {
        TourApp()
    }
}
