package com.example.bptours

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.res.painterResource

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TourAppTheme {
                TourApp()
            }
        }
    }
}

@Composable
fun TourApp(viewModel: TourViewModel = viewModel()) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Welcome to BP Tours",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { viewModel.loadTours() }) {
            Text("View Available Tours")
        }
        Spacer(modifier = Modifier.height(16.dp))

        TourList(tours = viewModel.tours)
    }
}

@Composable
fun TourList(tours: List<Tour>) {
    val listState = rememberLazyListState()
    LazyColumn(state = listState) {
        items(tours) { tour ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clickable { /* Future feature: Show tour details */ },
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Image(
                        painter = painterResource(id = tour.imageRes),
                        contentDescription = "Tour Image",
                        modifier = Modifier.fillMaxWidth().height(200.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = tour.name,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = tour.description)
                }
            }
        }
    }
}

class TourViewModel : androidx.lifecycle.ViewModel() {
    var tours by mutableStateOf(listOf<Tour>())
        private set

    fun loadTours() {
        tours = listOf(
            Tour("Tour A - London", "Explore the historic landmarks of London", R.drawable.london),
            Tour("Tour B - Paris", "Discover the romance of Paris", R.drawable.paris),
            Tour("Tour C - Rome", "Experience ancient Rome", R.drawable.rome),
            Tour("Tour D - Berlin", "Enjoy Berlin’s culture and history", R.drawable.berlin),
            Tour("Tour E - Madrid", "See the vibrant life of Madrid", R.drawable.madrid)
        )
    }
}

data class Tour(val name: String, val description: String, val imageRes: Int)

@Composable
fun TourAppTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = Color(0xFF6200EE),
        secondary = Color(0xFF03DAC5),
        background = Color.White,
        surface = Color.White,
        onPrimary = Color.White,
        onSecondary = Color.Black,
        onBackground = Color.Black,
        onSurface = Color.Black
    )

    MaterialTheme(
        colorScheme = colors,
        typography = Typography(),
        content = content
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewTourApp() {
    TourAppTheme {
        TourApp()
    }
}
